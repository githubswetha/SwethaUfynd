import os
import re
import scrapy
from ..items import BookingdotcomItem

###########################Fetch Html File From Current Directory###########################
path = os.getcwd()
for filename in os.listdir(path):
    if filename.endswith('.html'):
        FullPath = os.path.join(path,filename)
        fpath= "file:///"+FullPath
        
        class BookingSpider(scrapy.Spider):
            name = "Booking"
            start_urls = [
                fpath
                ]
            
            def parse(self, response):

                items = BookingdotcomItem()
                
                hname = response.css('#hp_hotel_name::text').get().replace("\n", "")
                haddress = response.css('#hp_address_subtitle::text').get().replace("\n", "")
                hratings = response.xpath('//*[@class="hp__hotel_ratings__stars hp__hotel_ratings__stars__clarification_track"]/i/@class').get().replace("b-sprite stars ratings_stars_", "")
                hratings = hratings.replace("  star_track", "")
                hreviewpoints = response.xpath('//*[@id="location_score_tooltip"]/p[1]/text()').get().replace(" location — rated ", "")
                hreviewpoints = hreviewpoints.replace("!", "")
                hnoreview = response.xpath('//*[@id="location_score_tooltip"]/p[1]/small/strong/text()').get()

                ###########################Hotel Description###########################
                hdecblock = response.css('.hotel_description_wrapper_exp ')
                description = hdecblock.css('p::text').getall()
                hdescription=''
                for i in description:
                    i.replace("\n", "")
                    hdescription += ' '+i

                ###########################Hotel Room Categories###########################
                hrcatblock = response.css('#maxotel_rooms')
                rhead = hrcatblock.css('th::text').getall()
                hroomheader=[]
                for i in rhead:
                    hroomheader.append(i.replace("\n", ""))
                roomoccupancy = hrcatblock.xpath('//*[@class="occ_no_dates"]/*/i/@title').getall()
                hroomoccupancy=[]
                for i in roomoccupancy:
                    hroomoccupancy.append(i.replace("Standard occupancy: ", ""))
                roomoccupancy = hrcatblock.xpath('//*[@class="occ_no_dates"]/i/@title').getall()
                for i in roomoccupancy:
                    hroomoccupancy.append(i.replace("Standard occupancy: ", ""))
                roomtype = hrcatblock.css('.ftd::text').getall()
                hroomtype=[]
                for i in roomtype:
                    hroomtype.append(i.replace("\n", ""))
                roomprice = hrcatblock.css('.b-button__text::text').getall()
                hroomprice=[]
                for i in roomprice:
                    hroomprice.append(i.replace("\n", ""))
                rtext = response.css('.hp_last_booking::text').get()
                plength=len(hroomprice)
                roomcategories = []
                roomcategories.append(rtext)
                for k in range(0,plength):
                    hroom = {hroomheader[0] : hroomoccupancy[k] , hroomheader[1] : hroomtype[k] , hroomheader[2] : hroomprice[k]}
                    roomcategories.append(hroom)

                ###########################Alternative Hotels###########################
                halthotelblock = response.css('#althotelsTable')
                althname = halthotelblock.css('.althotel_link::text').getall()
                halthname=[]
                for i in althname:
                    halthname.append(i.replace("\n", ""))
                althlink = halthotelblock.xpath('//*[@class="althotel_link"]/@href').getall()
                halthlink=[]
                for i in althlink:
                    halthlink.append(i.replace("\n", ""))
                althrat = halthotelblock.css('.invisible_spoken::text').getall()
                halthrat=[]
                for i in althrat:
                    halthrat.append(i.replace("\n", ""))
                althdes = halthotelblock.css('.hp_compset_description::text').getall()
                halthdes=[]
                for i in althdes:
                    halthdes.append(i.replace("\n", ""))
                althcurrview = halthotelblock.xpath('//*[@class="altHotels_most_recent_booking urgency_message_red"]/text()').getall()
                halthcurrview=[]
                for i in althcurrview:
                    halthcurrview.append(i.replace("\n", ""))
                halthscore=''
                halthscoreorg=[]
                halthscoreblock = halthotelblock.xpath('//div[@class="althotelsDiv alt_hotels_info_row"]')
                for h in halthscoreblock:
                    althscore = h.xpath('//span[@class="trackit score_from_number_of_reviews"]/text()').get()
                    halthscore += ' '+althscore
                    althscore1 = h.css('strong.count::text').get()
                    halthscore += ' '+althscore1
                    halthscore += ' reviews '
                    althscore2 = h.css('span.js--hp-scorecard-scoreword::text').get()
                    halthscore += ' '+althscore2
                    althscore3 = h.xpath('//span[@class="average js--hp-scorecard-scoreval"]/text()').get()
                    halthscore += ' '+althscore3
                    althscore4 = h.css('span.out_of::text').get()
                    halthscore += ' '+althscore4
                    althscore5 = h.css('span.best::text').get()
                    halthscore += ' '+althscore5
                    halthscoreorg.append(halthscore.replace("\n", ""))
                althboknowlink = halthotelblock.xpath('//*[@class="alt_hotels_info_row"]/a/@href').getall()
                althboknow = halthotelblock.xpath('//div[@class="alt_hotels_info_row"]/a/span[@class="b-button__text"]/text()').getall()
                alththemelink = halthotelblock.xpath('//*[@class="hotel_lp_alt_theme_links"]/@href').getall()
                alththeme = halthotelblock.xpath('//*[@class="hotel_lp_alt_theme_links"]/text()').getall()
                altrtext = response.css('#hp_cs_persuasive_headers::text').get().replace("\n", "")
                alternativehotels = []
                alternativehotels.append(altrtext)
                plen=len(halthname)
                halthotellist = []
                for k in range(0,plen):
                    althotel = {'Alternative Hotel Name' : halthname[k] , 'Alternative Hotel Ratings' : halthrat[k] , 'Alternative Hotel Description' : halthdes[k] , 'Alternative Hotel People Viewing' : halthcurrview[k] , 'Alternative Hotel Score' : halthscoreorg[k] , althboknow[k] : althboknowlink[k]}
                    halthotellist.append(althotel)
                alternativehotels.append(halthotellist)
                plengt=len(alththemelink)
                halththeme = []
                for k in range(0,plengt):
                    haltt = {alththeme[k] : alththemelink[k]}
                    halththeme.append(haltt)
                alternativehotels.append(halththeme)

                ###########################BookingDotCom Output Json Format###########################
                items['Hotelname'] = hname
                items['Address'] = haddress
                items['ClassificationStars'] = hratings
                items['Reviewpoints'] = hreviewpoints
                items['Numberofreviews'] = hnoreview
                items['Description'] = hdescription
                items['Roomcategories'] = roomcategories
                items['Alternativehotels'] = alternativehotels

                yield items
