# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class BookingdotcomItem(scrapy.Item):
    # define the fields for your item here like:
    Hotelname = scrapy.Field()
    Address = scrapy.Field()
    ClassificationStars = scrapy.Field()
    Reviewpoints = scrapy.Field()
    Numberofreviews = scrapy.Field()
    Description = scrapy.Field()
    Roomcategories = scrapy.Field()
    Alternativehotels = scrapy.Field()
